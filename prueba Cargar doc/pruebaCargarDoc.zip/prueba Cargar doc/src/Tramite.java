import java.time.LocalDate;
import java.util.Date;
import java.util.ArrayList;
import java.util.Scanner;


//LocalDate.now()

public class Tramite {
    private LocalDate FechaFinTramite;
    private LocalDate FechaIngresoTramite;
    private LocalDate FechaTopeDoc;
   private int nroTramite;
    static int cantidadTramites = 0;

    private TipoTramite tipoTramite;
    private ArrayList<DocEntregada> docEntregadas;

    public Tramite(int CTT) {
        this.nroTramite = ++cantidadTramites;
        //  System.out.println(); mostrar nro tramite generado
        this.FechaIngresoTramite = LocalDate.now();
        this.tipoTramite = new TipoTramite(CTT);

    }

    public LocalDate getFechaIngresoTramite() {
        return FechaIngresoTramite;
    }

    public int getNroTramite() {
        return nroTramite;
    }

    public LocalDate getFechaFinTramite() {
        return FechaFinTramite;
    }

    public TipoTramite getTipoTramite() {
        return tipoTramite;
    }
}
