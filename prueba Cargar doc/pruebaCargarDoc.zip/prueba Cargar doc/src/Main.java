import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       // Tramite hola = new Tramite();
        //Tramite chau = new Tramite();
        Scanner sc = new Scanner(System.in);

        /* PREGUNTAMOS SI DESEA CREAR UN NUEVO TRAMITE */

        System.out.println("Desea crear un nuevo tramite? ...");
        System.out.println("1 SI ");
        System.out.println("2 NO ");
        System.out.println("************************************");
        int desicion;
        desicion = sc.nextInt();

        if (desicion == 1){
            System.out.println("Ingrese CODIGO TIPO TRAMITE");
            int CTT;
            do {
                CTT = sc.nextInt();
                if(CTT<0 || CTT>4) System.out.println("Codigo de TIPO TRAMITE NO VÁLIDO, INTENTE NUEVAMENTE!!");
            }while(CTT<0 || CTT>4);
            Tramite nuevoTramite = new Tramite(CTT);
            System.out.println("**********************************");
            System.out.printf("Tramite creado con exito!!!");
            System.out.println("NUMERO DE TRAMITE : " + nuevoTramite.getNroTramite());
            System.out.println("Tipo de tramite: " + nuevoTramite.getTipoTramite().getNombreTipoTramite());
            System.out.println("Tramite creado el día: " + nuevoTramite.getFechaIngresoTramite());
            System.out.println("****************************************");
            System.out.println("La documentacion requerida para este Tipo De Tramite es: ");
          /*  TipoTramite tipoTramite = nuevoTramite.getTipoTramite();
            for (TipoDocumentaciones tipoDoc : tipoTramite.getTipoDocumentaciones()){
                System.out.println(tipoDoc.getNombreDoc());
            }
                ACA QUIERO MOSTRAR LA DOC FALTANTE
           */

            System.out.println("****************************************");
            System.out.println("CARGAR DOCUMENTACION");
            System.out.println("****************************************");
            System.out.println("INGRESE NRO TIPO DOCUMENTO: ");
            int codigoIngresado;
            codigoIngresado = sc.nextInt();

            for(TipoDocumentacion nro : nuevoTramite.getTipoTramite().getTipoDocumentaciones()){
            if(nro.getCodigoDoc() == codigoIngresado){
                if(nro.getDocEntregada().getFechaPresentada() == null){
                    nuevoTramite.getTipoTramite().getTipoDocumentaciones().get(0).entregarDocumentacion(codigoIngresado);
                    //set fecha today
                }
                else{
                    System.out.println("Ya se entrego esta documentacion!!!");
                }

            }
            else{
                System.out.println("El tipo de documentacion no corresponde al TIPO DE TRAMITE");
            }


            }




            //QUIERO buscar si para esa Instancia de tipo Doc Entregada con atributo codigoDoc == codigoIngresado la fechaDocEntregada == null

        //    nuevoTramite.getTipoTramite().getTipoDocumentaciones().get(0).entregarDocumentacion(codigoIngresado);
        }




    }
}